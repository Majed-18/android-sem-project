package com.example.attendancemanagementsystem;

import android.app.Application;


import java.util.ArrayList;

public class ApplicationContexts extends Application {
    private Faculty_class facultyClass;
    private AttendanceSession_class attendanceSessionClass;
    private ArrayList<Student_class> studentClassList;
    private ArrayList<Attendance_class> insertAttendanceIndbList;


    public Faculty_class getFacultyClass() {
        return facultyClass;
    }
    public void setFacultyClass(Faculty_class facultyClass) {
        this.facultyClass = facultyClass;
    }
    public AttendanceSession_class getAttendanceSessionClass() {
        return attendanceSessionClass;
    }
    public void setAttendanceSessionClass(AttendanceSession_class attendanceSessionClass) {
        this.attendanceSessionClass = attendanceSessionClass;
    }
    public ArrayList<Student_class> getStudentClassList() {
        return studentClassList;
    }
    public void setStudentClassList(ArrayList<Student_class> studentClassList) {
        this.studentClassList = studentClassList;
    }
    public ArrayList<Attendance_class> getInsertAttendanceIndbList() {
        return insertAttendanceIndbList;
    }
    public void setInsertAttendanceIndbList(ArrayList<Attendance_class> insertAttendanceIndbList) {
        this.insertAttendanceIndbList = insertAttendanceIndbList;
    }



}
